Font: the Bold Font

https://www.dafont.com/es/the-bold-font.font