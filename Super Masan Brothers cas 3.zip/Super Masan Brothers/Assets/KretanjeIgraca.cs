﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class KretanjeIgraca : MonoBehaviour {

    public float ubrzanjeX = 15f;
    public float maksimalnaBrzinaX = 5f;
    public float brzinaSkoka = 22f;
    public int brojSkokova = 1;//skokova koliko u ovom trenutku imamo na raspolaganju
    public int maksimalanBrojSkokova = 1;  
    private Vector2 brzina = new Vector2(0f, 0f);
    public bool naZemlji = false;
    public GameObject animacija;


	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        brzina = gameObject.GetComponent<Rigidbody2D>().velocity;
       

        if (Input.GetKey(KeyCode.D))
        {
            brzina.x = brzina.x+(ubrzanjeX*Time.deltaTime);
            
        }
        else if (Input.GetKey(KeyCode.A))
        {
            brzina.x -= (ubrzanjeX * Time.deltaTime);

        }
        else
        {
            if(brzina.x>0)
            {
                if (brzina.x < ubrzanjeX * Time.deltaTime) brzina.x = 0;
                else brzina.x -= (ubrzanjeX * Time.deltaTime);
            }
            if (brzina.x < 0)
            {
                if (brzina.x > -ubrzanjeX * Time.deltaTime) brzina.x = 0;
                else brzina.x += (ubrzanjeX * Time.deltaTime);
            }
        }
       

        if(Input.GetKeyDown(KeyCode.Space))
        {
            if (naZemlji)
            {
                brzina.y = brzinaSkoka;
            }
            else if (brojSkokova>0)
            {
                brzina.y = brzinaSkoka;
                brojSkokova--;
            }
            
        }


        if (brzina.x > maksimalnaBrzinaX) brzina.x = maksimalnaBrzinaX;
        if (brzina.x < -maksimalnaBrzinaX) brzina.x = -maksimalnaBrzinaX;


        gameObject.GetComponent<Rigidbody2D>().velocity = brzina;
        if (Mathf.Abs(brzina.x) > 0.05)
        {
           
          if(animacija!=null)  animacija.GetComponent<Animator>().SetBool("Trcanje", true);
        }
        else
        {

            if (animacija != null) animacija.GetComponent<Animator>().SetBool("Trcanje", false);
        }


        if(brzina.x<0)
        {
            animacija.GetComponent<SpriteRenderer>().transform.localScale = new Vector3(-1f, 1, 1);
        }
        else if (brzina.x > 0)
        {
            animacija.GetComponent<SpriteRenderer>().transform.localScale = new Vector3(1f, 1, 1);
        }

    }

    public void Die()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

}
