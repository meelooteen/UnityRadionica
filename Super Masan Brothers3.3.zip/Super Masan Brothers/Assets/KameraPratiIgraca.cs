﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KameraPratiIgraca : MonoBehaviour {

    public Transform kogaPratimo;
    public float mrtvaZonaX = 0f;
    public float mrtvaZonaY = 0f;
    public float offsetX = 0f;
    public float offsetY = 0f;
    public float brzinaKamere = 2;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {

        if(kogaPratimo!=null)
        {
            float novoX = transform.position.x;
            float novoY = transform.position.y;

            if (Mathf.Abs(novoX - (kogaPratimo.position.x + offsetX)) > mrtvaZonaX)
            {
                novoX = Mathf.Lerp (novoX,kogaPratimo.position.x + offsetX,Time.deltaTime*brzinaKamere);
            }

            if (Mathf.Abs(novoY - (kogaPratimo.position.y + offsetY)) > mrtvaZonaY)
            {
                novoY = Mathf.Lerp(novoY, kogaPratimo.position.y + offsetY, Time.deltaTime * brzinaKamere);
            }

            transform.position = new Vector3 (novoX,novoY, transform.position.z);
        }
		
	}
}
