﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NaZemlji : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    private void OnTriggerEnter2D(Collider2D other)
    {
        gameObject.GetComponentInParent<KretanjeIgraca>().naZemlji = true;
        gameObject.GetComponentInParent<KretanjeIgraca>().brojSkokova = gameObject.GetComponentInParent<KretanjeIgraca>().maksimalanBrojSkokova;
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        gameObject.GetComponentInParent<KretanjeIgraca>().naZemlji = false;
    }
}
