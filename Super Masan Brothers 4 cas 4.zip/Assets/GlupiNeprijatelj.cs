﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GlupiNeprijatelj : MonoBehaviour {

    public Transform lijevaIvica;
    public Transform desnaIvica;
    public float brzinaNeprijatelja;
    private float trenutnabrzinaNeprijatelja;
    private Vector2 brzina = new Vector2(0, 0);
    public float ubrzanje = 25f;
    public float smjer = -1;
    public AudioClip zvukSmrti;

    // Use this for initialization
    void Start() {
        trenutnabrzinaNeprijatelja = brzinaNeprijatelja;

    }

    // Update is called once per frame
    void Update() {
        brzina = gameObject.GetComponent<Rigidbody2D>().velocity;

        if (transform.position.x < lijevaIvica.position.x)
        {
            smjer = 1;
        }
        else if (transform.position.x > desnaIvica.position.x)
        {
            smjer = -1;
        }

        trenutnabrzinaNeprijatelja = trenutnabrzinaNeprijatelja + smjer * ubrzanje * Time.deltaTime;
        if(trenutnabrzinaNeprijatelja<-brzinaNeprijatelja) trenutnabrzinaNeprijatelja = -brzinaNeprijatelja;
        if (trenutnabrzinaNeprijatelja > brzinaNeprijatelja) trenutnabrzinaNeprijatelja = brzinaNeprijatelja;

        brzina.x = trenutnabrzinaNeprijatelja;

        gameObject.GetComponent<Rigidbody2D>().velocity = brzina;
        if (brzina.x < 0) gameObject.GetComponent<SpriteRenderer>().transform.localScale = new Vector3(-1f,1f,1f);
        else  gameObject.GetComponent<SpriteRenderer>().transform.localScale = new Vector3(1f, 1f, 1f);

    }

    public void Die()
    {
        GameObject.Find("AudioManager").GetComponent<AudioSource>().clip = zvukSmrti;
        GameObject.Find("AudioManager").GetComponent<AudioSource>().Play();
        Destroy(transform.parent.gameObject);
    }
}
