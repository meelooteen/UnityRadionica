﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KupljenjeKruske : MonoBehaviour {

    private void OnTriggerEnter2D(Collider2D collision)
    {

        Debug.Log("collision");
        if(collision.transform.tag=="Player")
        {
            GameManager.Poeni += 1;
            AudioClip clip;
            clip = gameObject.GetComponent<AudioSource>().clip;
            GameObject.Find("AudioManager").GetComponent<AudioSource>().clip= clip ;
            GameObject.Find("AudioManager").GetComponent<AudioSource>().Play();

            Destroy(gameObject);
        }
    }
}
