﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NeprijateljGlava : MonoBehaviour {
    public float odbijanjeIgraca = 0;


    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.tag=="Player")
        {
            collision.gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2(collision.gameObject.GetComponent<Rigidbody2D>().velocity.x, odbijanjeIgraca);
            GetComponentInParent<GlupiNeprijatelj>().Die();
            
        }
    }

}
