﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class NapustiIgru : MonoBehaviour {

    private void Start()
    {
        gameObject.GetComponent<Button>().onClick.AddListener(KliknutoDugme);
    }

    private void KliknutoDugme()
    {
        Debug.Log("NapustiIgru");
        Application.Quit();
    }
}
