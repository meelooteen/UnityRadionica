﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameOverPoeni : MonoBehaviour {

	// Use this for initialization
	void Start () {
        gameObject.GetComponent<Text>().text = "ОСВОЈЕНО ПОЕНА : " + GameManager.Poeni.ToString();
	}
	

}
