﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class KretanjeIgraca : MonoBehaviour {
    

    public float ubrzanjeX = 15f;
    public float maksimalnaBrzinaX = 5f;
    public float brzinaSkoka = 22f;
    public int brojSkokova = 1;//skokova koliko u ovom trenutku imamo na raspolaganju
    public int maksimalanBrojSkokova = 1;  
    private Vector2 brzina = new Vector2(0f, 0f);
    public bool naZemlji = false;
    public GameObject animacija;
    public float gravitacijaPada = 1;
    private float inicijalnaGravitacija;
    private Rigidbody2D rb;
    public float potisakSkoka = 1.8f;
    public AudioClip zvukSkoka;
    private bool mozeDaPuca = true;
    public float jacinaPucanja = 10;
    public Transform projektil;
    
    


	// Use this for initialization
	void Start () {
        rb = gameObject.GetComponent<Rigidbody2D>();
        inicijalnaGravitacija = rb.gravityScale;
      
	}
	
	// Update is called once per frame
	void Update () {

       

        brzina = gameObject.GetComponent<Rigidbody2D>().velocity;

        if (transform.parent != null)
        {
            brzina -= transform.parent.gameObject.GetComponent<Rigidbody2D>().velocity;
        }



        if (Input.GetKey(KeyCode.D))
        {
            brzina.x = brzina.x+(ubrzanjeX*Time.deltaTime);
            
        }
        else if (Input.GetKey(KeyCode.A))
        {
            brzina.x -= (ubrzanjeX * Time.deltaTime);

        }
        else
        {
            if(brzina.x>0)
            {
                if (brzina.x < ubrzanjeX * Time.deltaTime) brzina.x = 0;
                else brzina.x -= (ubrzanjeX * Time.deltaTime);
            }
            if (brzina.x < 0)
            {
                if (brzina.x > -ubrzanjeX * Time.deltaTime) brzina.x = 0;
                else brzina.x += (ubrzanjeX * Time.deltaTime);
            }
        }
       

        if(Input.GetKeyDown(KeyCode.Space))
        {

            if (brojSkokova > 0)
            {
                gameObject.GetComponent<AudioSource>().clip = zvukSkoka;
                gameObject.GetComponent<AudioSource>().pitch = Random.Range(0.6f,1.2f);
                gameObject.GetComponent<AudioSource>().Play();
            }

            if (naZemlji)
            {
                brzina.y = brzinaSkoka;
            }
            else if (brojSkokova>0)
            {
                brzina.y = brzinaSkoka;
                brojSkokova--;
            }

           
            
        }

        if (Input.GetMouseButtonDown(0))
        {
            Transform proj = Instantiate(projektil, transform.position, transform.rotation);
            
            proj.gameObject.GetComponent<ProjektilVatra>().sila = jacinaPucanja;
            Debug.Log("Pravac =" + proj.gameObject.GetComponent<ProjektilVatra>().pravac.x);

            Vector3 screenPoint = Input.mousePosition;
            Vector3 worldPoint = Camera.main.ScreenToWorldPoint(screenPoint);
            Vector2 smjer = new Vector2(0, 0);
            smjer.y = worldPoint.y - transform.position.y;
            smjer.x = worldPoint.x - transform.position.x;
            float ugao = Mathf.Atan2(smjer.x, smjer.y);
            proj.gameObject.GetComponent<ProjektilVatra>().brzinaRoditelja = brzina;
            proj.gameObject.GetComponent<ProjektilVatra>().pravac = new Vector2(Mathf.Sin(ugao),Mathf.Cos(ugao));




        }


        if (brzina.x > maksimalnaBrzinaX) brzina.x = maksimalnaBrzinaX;
        if (brzina.x < -maksimalnaBrzinaX) brzina.x = -maksimalnaBrzinaX;


        if (brzina.y >= 0) rb.gravityScale = inicijalnaGravitacija;
        else rb.gravityScale = inicijalnaGravitacija * gravitacijaPada;

       
       


        gameObject.GetComponent<Rigidbody2D>().velocity = brzina;
        if (transform.parent != null)
        {
            gameObject.GetComponent<Rigidbody2D>().velocity += transform.parent.gameObject.GetComponent<Rigidbody2D>().velocity;
        }




        if (Mathf.Abs(brzina.x) > 0.05)
        {

            if (animacija != null) { animacija.GetComponent<Animator>().SetBool("IgracTrci", true); }
        }
        else
        {

            if (animacija != null) animacija.GetComponent<Animator>().SetBool("IgracTrci", false);
        }


        if(brzina.x<0)
        {
            animacija.transform.localScale = new Vector3(-Mathf.Abs(animacija.transform.localScale.x), animacija.transform.localScale.y, animacija.transform.localScale.z);
        }
        else if (brzina.x > 0)
        {
            animacija.transform.localScale = new Vector3(Mathf.Abs(animacija.transform.localScale.x), animacija.transform.localScale.y, animacija.transform.localScale.z);
        }

    }

    private void FixedUpdate()
    {
        if (Input.GetKey(KeyCode.Space))
        {
            rb.AddForce(new Vector2(0f, potisakSkoka), ForceMode2D.Force);

        }

       

    }

    public void Die()
    {

        GameManager.Zivoti -= 1;
        if (GameManager.Zivoti >= 0)
        {      
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }
        else
        {
            SceneManager.LoadScene("GameOver");
        }

    }

}
