﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class GameManager  {

    private static int zivoti = 3;
    private static int poeni = 0;
    public static int poenaZaZivot = 10;
    private static int sakupljenoPoenaZaZivot = 0;
    private static int inicijalnoZivota = zivoti;
    public static string prvaScena = "Nivo2";


    public static void NovaIgra()
    {
        zivoti = inicijalnoZivota;
        poeni = 0;
        sakupljenoPoenaZaZivot = 0;
        SceneManager.LoadScene(prvaScena);
    }


    public static int Zivoti
    {
        get  {
            return zivoti;
        }
        set
        {
            zivoti = value;
            Debug.Log("Zivoti = "+value.ToString());
        }
    }

    public static int Poeni
    {
        get
        {
            return poeni;
        }

        set
        {
            int razlikaPoena = value - poeni;
            sakupljenoPoenaZaZivot += razlikaPoena;
            if(sakupljenoPoenaZaZivot>=poenaZaZivot)
            {
                sakupljenoPoenaZaZivot -= poenaZaZivot;
                zivoti += 1;
            }
            if(sakupljenoPoenaZaZivot<0)
            {
                sakupljenoPoenaZaZivot = 0;
            }
            poeni = value;
            Debug.Log("Poeni = " + value.ToString());
        }
    }
}
