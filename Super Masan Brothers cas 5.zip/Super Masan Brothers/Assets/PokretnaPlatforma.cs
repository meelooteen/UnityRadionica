﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PokretnaPlatforma : MonoBehaviour {

    public float brzinaKretanja = 1;
    public bool lijevo = false;
    private Vector2 brzina;

	// Use this for initialization
	void Start () {
        brzina = new Vector2(gameObject.GetComponent<Rigidbody2D>().velocity.x, gameObject.GetComponent<Rigidbody2D>().velocity.y);
	}
	
	// Update is called once per frame
	void Update () {
        if (lijevo) brzina.x = -brzinaKretanja;
        else brzina.x = brzinaKretanja;
        gameObject.GetComponent<Rigidbody2D>().velocity = brzina;	
	}

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.transform.tag!="Player")
        { 
        lijevo = !lijevo;
        }
        if (collision.transform.tag == "Player")
        {
            collision.transform.SetParent(transform);
        }
    }

  
    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.transform.tag == "Player")
        {
            collision.transform.SetParent(null);
        }
    }
}
