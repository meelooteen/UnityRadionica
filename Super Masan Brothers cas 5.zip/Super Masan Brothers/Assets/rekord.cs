﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class rekord : MonoBehaviour {

    private int trenutnirekord = 0;


	// Use this for initialization
	void Start () {

        
        trenutnirekord = PlayerPrefs.GetInt("Rekord", 0);

        Debug.Log(PlayerPrefs.GetInt("Rekord"));

        if (GameManager.Poeni>trenutnirekord)
        {
            trenutnirekord = GameManager.Poeni;
            PlayerPrefs.SetInt("Rekord", trenutnirekord);
            PlayerPrefs.Save();

           
        }
        gameObject.GetComponent<Text>().text = "Рекорд : " + trenutnirekord;
    }
	
	// Update is called once per frame
	void Update () {
		
	}
}
