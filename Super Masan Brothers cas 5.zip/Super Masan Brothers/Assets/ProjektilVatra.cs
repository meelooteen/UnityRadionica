﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProjektilVatra : MonoBehaviour {

    public Vector2 pravac = new Vector2(0,0);
    public float sila = 5;
    public float duzinaZivota=1f;
    public AudioClip zvuk;
    public Vector2 brzinaRoditelja= new Vector2(0,0);

	// Use this for initialization
	void Start () {
        gameObject.GetComponent<Rigidbody2D>().AddForce(pravac*sila+(brzinaRoditelja/2),ForceMode2D.Impulse);
        Destroy(gameObject, duzinaZivota);
        GameObject.Find("AudioManager").GetComponent<AudioSource>().clip = zvuk;
        GameObject.Find("AudioManager").GetComponent<AudioSource>().pitch = Random.Range(0.6f, 1.2f);
        GameObject.Find("AudioManager").GetComponent<AudioSource>().Play();



    }
	
	// Update is called once per frame
	void Update () {
		
	}

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.transform.tag=="Enemy")
            {
            collision.gameObject.GetComponent<GlupiNeprijatelj>().Die();
            Destroy(gameObject,0.1f);
        }
    }



}
