﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GledajUMisa : MonoBehaviour {

    // kojom maksimalnom brzinom želimo da okrećemo objekat - manja brzina je tečnija animacija, ali više laga
    public float brzina;

    void Update()
    {
        // Napravimo ravan koja počinje od onoga što rotiramo i ide gore
        Plane ravanTransformacije = new Plane(Vector3.up, transform.position);

        // Ispalimo zrak iz kamere ka onome iznad čega stoji miš 
        Ray zrak = Camera.main.ScreenPointToRay(Input.mousePosition);

        // Odredimo gdje taj zrak presijeca ravan koju smo napravili
        // Ovo je tačka u koju bi objekat trebalo da gleda, da bi "gledao u miša"
        // Bacanje zraka na ravan, na ovaj način, ne daje nam sve podatke. Izračunali smo udaljenost, 
        // ali sad treba da vidimo koja je to tačka koja se na zraku nalazi na toj udaljenosti. 
        // to je tačka u koju treba da gledamo.
        float udaljenost = 0.0f;
        // Ako zrak ne presijeca ravan, Raycast će vratiti "False"
        if (ravanTransformacije.Raycast(zrak, out udaljenost))
        {
            // Uzmimo tačku na zraku na definisanoj udaljenosti
            Vector3 tackaGledanja = zrak.GetPoint(udaljenost);

            // Odredimo rotaciju (tri arkustangensa) to je rotacija koju treba da primijenimo na objekat.
            Quaternion rotacija = Quaternion.LookRotation(tackaGledanja - transform.position);

            // Polako rotirajmo ka toj tački definisanom brzinom 
            //(da smo stavili da je transform.rotation=rotacija, rotirali bismo instantno)
            //Quaternion.Slerp je sferna interpolacija (https://en.wikipedia.org/wiki/Slerp)
            transform.rotation = Quaternion.Slerp(transform.rotation, rotacija, brzina * Time.deltaTime);
        }
    }
}
