﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GledajUMisa2 : MonoBehaviour {

    // kojom maksimalnom brzinom želimo da okrećemo objekat - manja brzina je tečnija animacija, ali više laga
    public float brzina;
    private Vector3 usmjerenje;

    void Update()
    {
        // Napravimo ravan koja počinje od onoga što rotiramo i ide gore
       

        // Ispalimo zrak iz kamere ka onome iznad čega stoji miš 
        Ray zrak = Camera.main.ScreenPointToRay(Input.mousePosition);

        // Odredimo gdje taj zrak presijeca ravan koju smo napravili
        // Ovo je tačka u koju bi objekat trebalo da gleda, da bi "gledao u miša"
        // Bacanje zraka na ravan, na ovaj način, ne daje nam sve podatke. Izračunali smo udaljenost, 
        // ali sad treba da vidimo koja je to tačka koja se na zraku nalazi na toj udaljenosti. 
        // to je tačka u koju treba da gledamo.
        
        RaycastHit pogodak ;
        if (Physics.Raycast(zrak, out pogodak)) {
            usmjerenje = pogodak.point;
        }
        // Ako zrak ne presijeca ravan, Raycast će vratiti "False"
        var lookDelta = (pogodak.point - transform.position);
        var targetRot = Quaternion.LookRotation(lookDelta);
        var rotSpeed = brzina * Time.deltaTime;
        transform.rotation = Quaternion.RotateTowards(transform.rotation, targetRot, rotSpeed);
    }
}
